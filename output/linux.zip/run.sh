chmod a+x EV\ Car\ UI
./EV\ Car\ UI